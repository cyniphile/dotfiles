# src/lib/pjrc

## links to original files

* [pjrc] (http://pjrc.com/teensy/)
    * [usb_keyboard] (http://pjrc.com/teensy/usb_keyboard.zip)
<!--
    * [usb_mouse] (http://pjrc.com/teensy/usb_mouse.zip)
    * [usb_serial] (http://pjrc.com/teensy/usb_serial.zip)
        * Directions for host setup [here]
          (http://pjrc.com/teensy/usb_serial.html)
-->

-------------------------------------------------------------------------------

Copyright &copy; 2012 Ben Blazak <benblazak.dev@gmail.com>  
Released under The MIT License (MIT) (see "license.md")  
Project located at <https://github.com/benblazak/ergodox-firmware>

